 import { movies } from "./movies-data.js";


export function getlang() {
    const resultlan = movies.reduce((result, movie) => {
        movie.audio.languages.forEach(zaban => {
            if (!result.includes(zaban)) {
                result = result.concat(zaban);
            }
        });

        return result;
    }, []);

    return resultlan;
}


export function getcountry() {
    const resultcon = movies.reduce((result, movie) => {
        movie.countries.forEach(c => {
            if (!result.includes(c.country)) {
                result = result.concat(c.country);
            }
        });

        return result;
    }, []);

    return resultcon;
}


export function getgenre() {
    const resultgen = movies.reduce((result, movie) => {
        movie.categories.forEach(c => {
            if (!result.includes(c.title_en)) {
                result = result.concat(c.title_en);
            }
        });

        return result;
    }, []);

    const allcat = movies.reduce((result, movie) => {
        return result.concat(movie.categories);
    }, []);

    const fondgen = resultgen.map(key => {
        const fond = allcat.find(c => {
            return c.title_en === key;
        });

        return {
            key: key,
            title: fond.title
        };
    });

    return fondgen;
}


export function getage() {
    const resultage = movies.reduce((result, movie) => {
        if (!result.includes(movie.age_range)) {
            result = result.concat(movie.age_range);
        }

        return result;
    }, []);

    return resultage;
}


export function applayfilter(filters) {
    return movies.filter(movie => {

        if (filters.director) {
            if (!movie.director.includes(filters.director)) {
                return false;
            }
        }

        if (filters.minImdb) {
            if (Number(movie.imdb_rate) < Number(filters.minImdb)) {
                return false;
            }
        }

        if (filters.age) {
            if (movie.age_range !== filters.age) {
                return false;
            }
        }

        if (filters.language) {
            if (!movie.audio.languages.includes(filters.language)) {
                return false;
            }
        }

        if (filters.country) {
            const hasCountry = movie.countries.some(c => c.country === filters.country);
            if (!hasCountry) {
                return false;
            }
        }

        if (filters.genre) {
            const hasGenre = movie.categories.some(c => c.title_en === filters.genre);
            if (!hasGenre) {
                return false;
            }
        }

        if (filters.yearFrom || filters.yearTo) {
            const year = Number(String(movie.pro_year).replace(/[۰-۹]/g, d => "۰۱۲۳۴۵۶۷۸۹".indexOf(d)));

            if (filters.yearFrom) {
                if (year < Number(filters.yearFrom)) {
                    return false;
                }
            }

            if (filters.yearTo) {
                if (year > Number(filters.yearTo)) {
                    return false;
                }
            }
        }

        if (filters.audioType === "dubbed") {
            if (!movie.dubbed.enable) {
                return false;
            }
        }

        if (filters.audioType === "original") {
            if (movie.dubbed.enable) {
                return false;
            }
        }

        return true;
    });
}


export function removemovi(list) {
    return list.filter((movie, index) => {
        return list.findIndex(item => item.id === movie.id) === index;
    });
}


export function sortMovies(list, order) {

    if (order === "newest") {
        return [...list].sort((a, b) => {
            const yearA = Number(String(a.pro_year).replace(/[۰-۹]/g, d => "۰۱۲۳۴۵۶۷۸۹".indexOf(d)));
            const yearB = Number(String(b.pro_year).replace(/[۰-۹]/g, d => "۰۱۲۳۴۵۶۷۸۹".indexOf(d)));
            return yearB - yearA;
        });
    }

    if (order === "oldest") {
        return [...list].sort((a, b) => {
            const yearA = Number(String(a.pro_year).replace(/[۰-۹]/g, d => "۰۱۲۳۴۵۶۷۸۹".indexOf(d)));
            const yearB = Number(String(b.pro_year).replace(/[۰-۹]/g, d => "۰۱۲۳۴۵۶۷۸۹".indexOf(d)));
            return yearA - yearB;
        });
    }

    if (order === "toprated") {
        return [...list].sort((a, b) => b.imdb_rate - a.imdb_rate);
    }

    return list;
}