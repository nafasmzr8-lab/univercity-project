 import { movies } from "./movies-data.js";
import { genreColors } from "./gener.js";

export function createMovieCard(movie) {
    const card = document.createElement("div");
    card.className = "movie-card";
    card.onclick = function() {
        window.location.href = "detail.html?id=" + movie.id;
    };
    const countries = movie.countries
        .map(c => c.country)
        .join("، ");
    const languages = movie.audio.languages
        .join("، ");

    const genreBadges = movie.categories
        .map(c => {
            const colors = genreColors[c.title_en] || {
                background: "#E5E7EB",
                color: "#374151",
            };
            return `<span class="genre-badge" style="background:${colors.background}; color:${colors.color};">${c.title}</span>`;
        })
        .join("");

    card.innerHTML = 
        `<div class="movie-poster">
            <img src="${movie.pic.movie_img_m}" alt="${movie.movie_title}" loading="lazy" onerror="this.src='${movie.pic.movie_img_s}'">
        </div>
        <div class="movie-info">
            <h3 class="movie-title">${movie.movie_title}</h3>
            <div class="movie-meta-row">
                <span class="imdb-score">IMDB ${movie.imdb_rate}</span>
                <span class="like-percent">👍 ${movie.avg_rate_label}</span>
            </div>
            <div class="movie-genres">${genreBadges}</div>
            <p>سال: ${movie.pro_year}</p>
            <p>کارگردان: ${movie.director}</p>
            <p>رده سنی: ${movie.age_range}</p>
            <p>کشور: ${countries}</p>
            <p>زبان: ${languages}</p>
        </div>`
    ;
    return card;
}


let currentList = [];
let shownCount = 0;
const pageSize = 20;

export function renderMovieList(list) {
    currentList = list;
    shownCount = 0;
    const cart = document.getElementById("cart");
    cart.innerHTML = "";
    showNextPage();
}

function showNextPage() {
    const cart = document.getElementById("cart");
    const nextMovies = currentList.slice(shownCount, shownCount + pageSize);

    nextMovies.forEach(movie => {
        const card = createMovieCard(movie);
        cart.appendChild(card);
    });

    shownCount += nextMovies.length;

    const oldButton = document.getElementById("loadMoreBtn");
    if (oldButton) {
        oldButton.remove();
    }

    if (shownCount < currentList.length) {
        const button = document.createElement("button");
        button.id = "loadMoreBtn";
        button.textContent = "نمایش بیشتر (" + (currentList.length - shownCount) + " فیلم دیگر)";
        button.onclick = showNextPage;
        cart.after(button);
    }
}

export function renderMovies() {
    renderMovieList(movies);
}