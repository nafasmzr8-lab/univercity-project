 import { movies } from "./movies-data.js";

const param = new URLSearchParams(window.location.search);
const movieid = param.get("id");

const movie = movies.find(m => {
    return m.id === movieid;
});
document.getElementById("idname").textContent = movie.movie_title;

const posterImg = document.getElementById("c-1");
posterImg.src = movie.pic.movie_img_m;
posterImg.onerror = function() {
    posterImg.src = movie.pic.movie_img_s;
};
const bgImg = new Image();
bgImg.src = movie.pic.movie_img_b;
bgImg.onload = function() {
    document.getElementById("bg").style.backgroundImage = `url(${movie.pic.movie_img_b})`;
};
bgImg.onerror = function() {
    document.getElementById("bg").style.backgroundImage = `url(${movie.pic.movie_img_m})`;
};

const scap = movie.descr.slice(0, 150) + "...";
document.getElementById("cap").textContent = scap;

function showFullCaption() {
    document.getElementById("cap").textContent = movie.descr;
    document.getElementById("btn").style.display = "none";
}

window.showFullCaption = showFullCaption;