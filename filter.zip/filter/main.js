 import {
    getlang,
    getcountry,
    getgenre,
    getage,
    applayfilter,
    removemovi,
    sortMovies
} from "./filters.js";

import {
    renderMovies,
    renderMovieList
} from "./render.js";
function initPage() {
    renderMovies();
    const languageList = getlang();
    const countryList = getcountry();
    const genreList = getgenre();
    const ageList = getage();
    const languageSelect = document.getElementById("zaban");
    const countrySelect = document.getElementById("contry");
    const genreSelect = document.getElementById("genre");
    const ageSelect = document.getElementById("radseni");

    languageList.forEach(language => {
        languageSelect.innerHTML += 
            `<option value="${language}">${language}</option>`
        ;
    });

    countryList.forEach(country => {
        countrySelect.innerHTML += 
            `<option value="${country}">${country}</option>`
        ;
    });

    genreList.forEach(genre => {
        genreSelect.innerHTML += 
            `<option value="${genre.key}">${genre.title}</option>`
        ;
    });

    ageList.forEach(age => {
        ageSelect.innerHTML += 
            `<option value="${age}">${age}</option>`
        ;
    });
}

function togadpanel() {
    const panel = document.getElementById("addpanel");
    if (panel.style.display === "none") {
        panel.style.display = "grid";
    } else {
        panel.style.display = "none";
    }
}

function chek1() {
    const chek1 = document.getElementById("chek-1");
    const chek2 = document.getElementById("chek-2");
    if (chek1.checked) {
        chek2.checked = false;
    }
}

function chek2() {
    const chek1 = document.getElementById("chek-1");
    const chek2 = document.getElementById("chek-2");
    if (chek2.checked) {
        chek1.checked = false;
    }
}

function handserch() {
    const filters = {
        director: document.getElementById("kar").value,
        minImdb: document.getElementById("emtiaz").value,
        age: document.getElementById("radseni").value,
        language: document.getElementById("zaban").value,
        country: document.getElementById("contry").value,
        genre: document.getElementById("genre").value,
        yearFrom: document.getElementById("sal-1").value,
        yearTo: document.getElementById("sal-2").value,
        audioType: document.getElementById("chek-1").checked
            ? "dubbed"
            : document.getElementById("chek-2").checked
            ? "original"
            : ""
    };
    let result = applayfilter(filters);
    result = removemovi(result);
    const order = document.getElementById("tartib").value;
    result = sortMovies(result, order);
    renderMovieList(result);
    const nt = document.getElementById("nt");
    nt.innerHTML = result.length + " فیلم";
}
window.togadpanel = togadpanel;
window.chek1 = chek1;
window.chek2 = chek2;
window.handserch = handserch;

initPage();